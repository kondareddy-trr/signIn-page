import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
username:string;
  constructor() { }
  findAcc(){
  if (this.username == "kondareddy")
  {
    var url="link";
  var myWindow = window.open('', "", "width=500, height=500");   // Opens a new window
myWindow.document.write("this is your verification link<br/>");
 myWindow.document.write("<a href='/link'>"+url+"</a>" )    // Some text in the new window
myWindow.focus();

  }
  else {
     var myWindow = window.open('', "", "width=500, height=500");   // Opens a new window
myWindow.document.write("Username not found");
myWindow.focus();
  }

   
}
  ngOnInit() {
  }

}
