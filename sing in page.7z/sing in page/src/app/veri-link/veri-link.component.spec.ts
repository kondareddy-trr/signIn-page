import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VeriLinkComponent } from './veri-link.component';

describe('VeriLinkComponent', () => {
  let component: VeriLinkComponent;
  let fixture: ComponentFixture<VeriLinkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VeriLinkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VeriLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
