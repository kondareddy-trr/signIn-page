import { Component, OnInit } from '@angular/core';
import {FormGroup,Validators,FormControl} from '@angular/forms';

@Component({
  selector: 'app-veri-link',
  templateUrl: './veri-link.component.html',
  styleUrls: ['./veri-link.component.css']
})
export class VeriLinkComponent implements OnInit {

  changePasswordForm;
  password: FormControl;
  confirmPassword: FormControl;
  passwordCheck;
  confirmPasswordError:boolean=true;
  constructor() { }

  ngOnInit() {
    this.changePasswordFormValidations();
    this.changePasswordFormIntialization();
  }

  changePasswordFormValidations(){
    this.password = new FormControl("", [
      Validators.required, Validators.pattern("(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,15}")
    ]);
    this.confirmPassword = new FormControl("", Validators.compose([
      Validators.required]));
  }

  changePasswordFormIntialization(){
    this.changePasswordForm = new FormGroup({
      password: this.password,
      confirmPassword: this.confirmPassword,
    });
  }

  ConfirmPasswordCheck(confirmPassword){
    if(this.passwordCheck === confirmPassword){
      this.confirmPasswordError = false;
    }
    else
    {
      this.confirmPasswordError = true;
    }
  }
  changePasswordSubmit()
  {
    alert("Password" +this.passwordCheck)
  }

}
